package in.uskcorp.tool.das.service;

import in.uskcorp.tool.das.domain.Department;

public abstract class DepartmentService extends APIService<Department> {
}
