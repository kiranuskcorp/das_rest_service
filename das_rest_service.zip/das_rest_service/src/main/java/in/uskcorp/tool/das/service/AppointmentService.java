package in.uskcorp.tool.das.service;

import java.util.List;

import in.uskcorp.tool.das.domain.Appointment;

public abstract class AppointmentService extends APIService<Appointment> {
	
}
