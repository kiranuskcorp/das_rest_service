package in.uskcorp.tool.das.dao;

import in.uskcorp.tool.das.domain.Appointment;

public abstract class AppointmentDAO extends APIDAO<Appointment> {

}
