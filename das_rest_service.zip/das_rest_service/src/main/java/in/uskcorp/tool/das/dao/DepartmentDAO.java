package in.uskcorp.tool.das.dao;

import in.uskcorp.tool.das.domain.Department;

public abstract class DepartmentDAO extends APIDAO<Department> {
}
