package in.uskcorp.tool.das.service;

import in.uskcorp.tool.das.domain.Diseases;
import in.uskcorp.tool.das.domain.Specialization;

import java.util.List;

public abstract class DiseasesService extends APIService<Diseases>{

	
}
