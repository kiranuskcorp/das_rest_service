package in.uskcorp.tool.das.dao;

import in.uskcorp.tool.das.domain.Role;

public abstract class RoleDAO extends APIDAO<Role> {

}
