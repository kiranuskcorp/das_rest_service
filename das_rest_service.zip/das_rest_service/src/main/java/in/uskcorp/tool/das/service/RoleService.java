package in.uskcorp.tool.das.service;

import in.uskcorp.tool.das.domain.Role;

public abstract class RoleService extends APIService<Role> {

}
