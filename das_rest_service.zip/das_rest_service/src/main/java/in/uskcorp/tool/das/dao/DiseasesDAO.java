package in.uskcorp.tool.das.dao;

import in.uskcorp.tool.das.domain.Diseases;

public abstract class DiseasesDAO extends APIDAO<Diseases> {

}
